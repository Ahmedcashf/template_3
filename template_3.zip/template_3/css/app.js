console.log("hello world!");
console.error("that error")
console.warn("that warn");
typeof "whaف"
/*تقدر تكتبف برحتك*/
let v ="cashf"
let h = "swp"
console.log(v + " " + h)
console.log(`the student ${v} has ${h}`);
/*array*/
let array=["cashf", 2 , true]
console.log(array)
array.push("swp")
console.log(array)
array.pop()
console.log(array)
console.log(array.slice(1,2))

/*object*/
let student = {
    name:"cashf",
    age:23,
    vuv:['cashf']
}

console.log(student)

student.age='30'
student["template"] = 3

console.log(student)

/*function , method*/

function getarea(width , height) {
    let area ;
    area=width*height;
    return area;
}

function getperimeter(width , height) {
    let perimeter ;
    perimeter=(width+height)*2;
    return perimeter;
}

console.log(getarea(4,8))
console.log(getperimeter(4,8))

/*if else */

if(v==="cashf") {
    console.log(true)
}

//task

function arrayc (num) {


    for (let i = 0; i < num.length; i++) {
        
        if (num[i]%2===0) {

            num[i]=num[i]*2

        }
        else {

            num[i]=num[i]*3
        
        }
    }

 return num
}

gogo = [1,3,6]

let x = arrayc (gogo)






